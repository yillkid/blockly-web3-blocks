Blockly.Msg.digitalWrite = "Digital Write";
Blockly.Msg.digitalRead = "Digital Read";