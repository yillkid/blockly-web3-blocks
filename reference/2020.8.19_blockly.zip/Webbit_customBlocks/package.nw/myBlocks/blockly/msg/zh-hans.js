MSG.myBlocks = "我的积木";
MSG.myCategory1 = "目录 1";
MSG.myCategory2 = "目录 2";