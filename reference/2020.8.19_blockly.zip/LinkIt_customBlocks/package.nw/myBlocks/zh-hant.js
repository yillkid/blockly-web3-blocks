Blockly.Msg.digitalWrite = "數位輸出";
Blockly.Msg.digitalRead = "數位輸入";